# DROMA MCP Server

A Model Context Protocol (MCP) server that provides access to DROMA.R drug-omics association analysis functions through a standardized interface. This server allows AI assistants to interact with your comprehensive drug-omics analysis capabilities using the [FastMCP framework](https://github.com/jlowin/fastmcp).

## Overview

The DROMA MCP Server bridges your R-based DROMA.R and DROMA.Set packages with the Model Context Protocol, enabling AI assistants to:

- Create and manage DromaSet and MultiDromaSet objects
- Perform drug-omics association analysis
- Execute batch feature analysis across multiple datasets
- Generate publication-quality visualizations
- Retrieve and summarize drug sensitivity data
- Get intelligent analysis interpretation guidance

## Features

### 🔧 Tools Available

- **`create_dromaset_from_database`**: Create DromaSet objects from DROMA databases
- **`create_multidromaset_from_database`**: Create MultiDromaSet objects for cross-project analysis
- **`analyze_drug_omic_pair`**: Analyze associations between drugs and omics features
- **`batch_find_significant_features`**: Perform batch analysis to find significant associations
- **`create_volcano_plot`**: Generate volcano plots from batch analysis results
- **`get_drug_sensitivity_data`**: Retrieve comprehensive drug sensitivity data

### 📊 Resources

- **`droma://database/info`**: Get database connection information
- **`droma://projects/{project_name}/info`**: Get detailed project information

### 💡 Prompts

- **`drug_analysis_prompt`**: Generate analysis interpretation guidance
- **`batch_analysis_interpretation`**: Provide batch results interpretation

## Installation

### Prerequisites

1. **Python 3.10+** with the following packages:
   ```bash
   pip install fastmcp rpy2 pandas numpy
   ```

2. **R environment** with DROMA packages:
   ```r
   # Install DROMA.Set and DROMA.R packages in R
   # (Follow your DROMA installation instructions)
   library(DROMA.Set)
   library(DROMA.R)
   ```

3. **R dependencies** - Ensure these R packages are installed:
   ```r
   install.packages(c("meta", "metafor", "effsize", "ggplot2", "dplyr", 
                     "ggpubr", "DT", "htmltools", "patchwork", "jsonlite"))
   ```

### Setup

1. Clone or download the DROMA MCP Server files
2. Ensure your R files are in the `Ref/R/` directory
3. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

### Starting the Server

#### Local/Command Line Usage (STDIO)
```bash
python droma_mcp_server.py
```

#### Web Deployment (HTTP)
```bash
python -c "
from droma_mcp_server import mcp
mcp.run(transport='streamable-http', host='127.0.0.1', port=8000, path='/mcp')
"
```

#### Server-Sent Events (SSE)
```bash
python -c "
from droma_mcp_server import mcp
mcp.run(transport='sse', host='127.0.0.1', port=8000)
"
```

### Using with AI Assistants

Once the server is running, AI assistants can use the MCP tools to perform drug-omics analysis. Here are example workflows:

#### 1. Basic Drug-Omics Analysis
```python
# The AI assistant can call these tools:
# 1. Create a dataset
create_dromaset_from_database("gCSI", "/path/to/droma.sqlite")

# 2. Analyze drug-omics association
analyze_drug_omic_pair("mRNA", "ABCB1", "Paclitaxel", ["gCSI"])

# 3. Get interpretation guidance
drug_analysis_prompt("Paclitaxel", "ABCB1")
```

#### 2. Batch Analysis Workflow
```python
# 1. Create multi-project dataset
create_multidromaset_from_database(["gCSI", "CCLE"], "/path/to/droma.sqlite")

# 2. Find features associated with drug response
batch_find_significant_features("drug", "Paclitaxel", "mRNA", ["gCSI", "CCLE"])

# 3. Create visualization
create_volcano_plot(analysis_results, 0.3, 0.05)

# 4. Get interpretation
batch_analysis_interpretation("Paclitaxel", "drug", 45, 1000)
```

### Configuration

The server automatically sources R files from the `Ref/R/` directory. Ensure your DROMA.R functions are available:

```
project/
├── droma_mcp_server.py
├── requirements.txt
├── Ref/R/
│   ├── FuncBatchFeature.R
│   ├── FuncDataLoaders.R
│   ├── FuncDrugFeature.R
│   ├── FuncDrugOmicPair.R
│   ├── FuncZscoreWhole.R
│   └── theme_utils.R
└── README.md
```

## API Reference

### Tools

#### `create_dromaset_from_database`
Create a DromaSet object from a DROMA database.

**Parameters:**
- `project_name` (str): Name of the project (e.g., 'gCSI', 'CCLE')
- `db_path` (str): Path to the DROMA SQLite database

**Returns:** Status message indicating success or failure

#### `analyze_drug_omic_pair`
Analyze association between a drug and an omics feature.

**Parameters:**
- `omics_type` (str): Type of omics data ('mRNA', 'mutation_gene', 'cnv', etc.)
- `omics_name` (str): Name of the omics feature
- `drug_name` (str): Name of the drug
- `project_names` (List[str], optional): List of project names
- `data_type` (str): Filter by data type ('all', 'CellLine', 'PDX', etc.)
- `tumor_type` (str): Filter by tumor type
- `overlap_only` (bool): Whether to use only overlapping samples

**Returns:** JSON string containing meta-analysis results

#### `batch_find_significant_features`
Perform batch analysis to find features significantly associated with a reference feature.

**Parameters:**
- `feature1_type` (str): Type of reference feature
- `feature1_name` (str): Name of reference feature
- `feature2_type` (str): Type of features to test against
- `project_names` (List[str], optional): List of project names
- `cores` (int): Number of CPU cores for parallel processing
- `test_top_100` (bool): Whether to test only top 100 features

**Returns:** JSON string containing significant features and statistics

### Resources

#### `droma://database/info`
Get information about the connected DROMA database.

#### `droma://projects/{project_name}/info`
Get detailed information about a specific project including available drugs and molecular profiles.

### Prompts

#### `drug_analysis_prompt(drug_name, omics_feature)`
Generate comprehensive guidance for interpreting drug-omics analysis results.

#### `batch_analysis_interpretation(feature_name, feature_type, significant_count, total_count)`
Provide interpretation framework for batch analysis results.

## Error Handling

The server includes comprehensive error handling:

- **R Interface Errors**: Graceful fallback when R or packages are unavailable
- **Database Errors**: Clear messages for missing or invalid database files
- **Analysis Errors**: Detailed error reporting for failed analyses
- **Progress Reporting**: Real-time progress updates for long-running analyses

## Examples

### Example 1: Single Drug-Gene Analysis
```python
# AI assistant workflow:
# 1. Create dataset
result = create_dromaset_from_database("gCSI", "/data/droma.sqlite")

# 2. Analyze ABCB1 gene expression vs Paclitaxel sensitivity
analysis = analyze_drug_omic_pair("mRNA", "ABCB1", "Paclitaxel", ["gCSI"])

# 3. Get interpretation guidance
guidance = drug_analysis_prompt("Paclitaxel", "ABCB1")
```

### Example 2: Multi-Project Meta-Analysis
```python
# 1. Create multi-project dataset
multi_result = create_multidromaset_from_database(["gCSI", "CCLE"], "/data/droma.sqlite")

# 2. Cross-project analysis
meta_analysis = analyze_drug_omic_pair(
    "mutation_gene", "TP53", "Cisplatin", 
    ["gCSI", "CCLE"], overlap_only=False
)
```

### Example 3: Batch Biomarker Discovery
```python
# 1. Find all genes associated with drug response
batch_results = batch_find_significant_features(
    "drug", "Paclitaxel", "mRNA", ["gCSI", "CCLE"], 
    cores=4, test_top_100=False
)

# 2. Create volcano plot
plot_path = create_volcano_plot(batch_results, 0.3, 0.05)

# 3. Get interpretation
interpretation = batch_analysis_interpretation("Paclitaxel", "drug", 45, 1000)
```

## Integration with Claude Desktop

To use this server with Claude Desktop, add the following to your MCP configuration:

```json
{
  "mcpServers": {
    "droma": {
      "command": "python",
      "args": ["/path/to/droma_mcp_server.py"],
      "env": {
        "R_HOME": "/usr/local/lib/R"
      }
    }
  }
}
```

## Troubleshooting

### Common Issues

1. **R Interface Not Available**
   - Ensure `rpy2` is installed: `pip install rpy2`
   - Check R installation and PATH
   - Verify DROMA packages are installed in R

2. **Database Connection Issues**
   - Verify database file path
   - Check file permissions
   - Ensure database is a valid DROMA SQLite file

3. **Analysis Errors**
   - Check that specified features exist in the database
   - Ensure sufficient sample sizes for analysis
   - Verify project names match database contents

### Performance Tips

- Use `test_top_100=True` for initial batch analyses
- Leverage parallel processing with `cores > 1`
- Consider `overlap_only=True` for meta-analyses requiring comparable samples
- Use appropriate filtering by `data_type` and `tumor_type`

## Contributing

This MCP server is designed to work with your existing DROMA.R and DROMA.Set packages. To extend functionality:

1. Add new R functions to the appropriate files in `Ref/R/`
2. Create corresponding MCP tools in `droma_mcp_server.py`
3. Update this README with new functionality

## License

This project follows the same license as your DROMA.R and DROMA.Set packages.

## Citation

If you use this MCP server in your research, please cite both the DROMA packages and the FastMCP framework:

```
DROMA.R and DROMA.Set: [Your existing citation]
FastMCP: https://github.com/jlowin/fastmcp
```

---

**DROMA MCP Server** - Bridging advanced drug-omics analysis with AI assistants through the Model Context Protocol 🧬💊🤖 