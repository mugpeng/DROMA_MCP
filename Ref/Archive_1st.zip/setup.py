#!/usr/bin/env python3
"""
Setup script for DROMA MCP Server
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="droma-mcp-server",
    version="1.0.0",
    author="DROMA Project Team",
    author_email="yc47680@um.edu.mo",
    description="Model Context Protocol server for DROMA drug-omics analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-repo/droma-mcp-server",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0",
            "black>=22.0",
            "flake8>=5.0",
            "mypy>=1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "droma-mcp-server=droma_mcp_server:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["Ref/R/*.R"],
    },
    keywords="bioinformatics, drug-omics, mcp, model-context-protocol, cancer-research",
    project_urls={
        "Bug Reports": "https://github.com/your-repo/droma-mcp-server/issues",
        "Source": "https://github.com/your-repo/droma-mcp-server",
        "Documentation": "https://github.com/your-repo/droma-mcp-server/blob/main/README.md",
    },
) 