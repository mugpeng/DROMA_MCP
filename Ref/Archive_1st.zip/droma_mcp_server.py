#!/usr/bin/env python3
"""
DROMA MCP Server

A Model Context Protocol server that provides access to DROMA.R drug-omics
association analysis functions through a standardized interface.

This server exposes the key DROMA.R functions as MCP tools, allowing AI assistants
to perform drug-omics analysis, batch feature analysis, and visualization.
"""

import asyncio
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from fastmcp import FastMCP, Context

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize the MCP server
mcp = FastMCP("DROMA Analysis Server")

# Global R interface - will be initialized when needed
r_interface = None

class DROMAInterface:
    """Interface to DROMA.R functions using rpy2"""
    
    def __init__(self):
        self.r = None
        self._initialize_r()
    
    def _initialize_r(self):
        """Initialize R interface and load DROMA packages"""
        try:
            import rpy2.robjects as robjects
            from rpy2.robjects import pandas2ri
            from rpy2.robjects.packages import importr
            
            # Activate pandas conversion
            pandas2ri.activate()
            
            self.r = robjects.r
            
            # Try to load DROMA packages
            try:
                self.r('library(DROMA.Set)')
                self.r('library(DROMA.R)')
                logger.info("Successfully loaded DROMA packages")
            except Exception as e:
                logger.warning(f"Could not load DROMA packages: {e}")
                logger.info("You may need to install DROMA.Set and DROMA.R packages in R")
            
            # Source the R functions if they exist locally
            r_files_dir = Path("Ref/R")
            if r_files_dir.exists():
                for r_file in r_files_dir.glob("*.R"):
                    try:
                        self.r(f'source("{r_file}")')
                        logger.info(f"Sourced {r_file}")
                    except Exception as e:
                        logger.warning(f"Could not source {r_file}: {e}")
        
        except ImportError:
            logger.error("rpy2 not available. Please install rpy2 to use R functions.")
            self.r = None
    
    def is_available(self) -> bool:
        """Check if R interface is available"""
        return self.r is not None
    
    def execute_r_code(self, code: str) -> Any:
        """Execute R code and return result"""
        if not self.is_available():
            raise RuntimeError("R interface not available")
        
        try:
            result = self.r(code)
            return result
        except Exception as e:
            logger.error(f"R execution error: {e}")
            raise

def get_r_interface():
    """Get or create R interface singleton"""
    global r_interface
    if r_interface is None:
        r_interface = DROMAInterface()
    return r_interface

@mcp.tool()
async def create_dromaset_from_database(
    project_name: str,
    db_path: str,
    ctx: Context
) -> str:
    """
    Create a DromaSet object from a DROMA database.
    
    Args:
        project_name: Name of the project (e.g., 'gCSI', 'CCLE')
        db_path: Path to the DROMA SQLite database
        
    Returns:
        Status message indicating success or failure
    """
    await ctx.info(f"Creating DromaSet for project: {project_name}")
    
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "Error: R interface not available. Please install rpy2 and DROMA packages."
    
    try:
        # Check if database file exists
        if not os.path.exists(db_path):
            return f"Error: Database file not found at {db_path}"
        
        r_code = f"""
        connectDROMADatabase("{db_path}")
        {project_name} <- createDromaSetFromDatabase("{project_name}", "{db_path}")
        paste("Successfully created DromaSet for", "{project_name}")
        """
        
        result = r_interface.execute_r_code(r_code)
        await ctx.info(f"DromaSet created successfully for {project_name}")
        return str(result[0])
        
    except Exception as e:
        error_msg = f"Error creating DromaSet: {str(e)}"
        await ctx.error(error_msg)
        return error_msg

@mcp.tool()
async def create_multidromaset_from_database(
    project_names: List[str],
    db_path: str,
    ctx: Context
) -> str:
    """
    Create a MultiDromaSet object from multiple projects in a DROMA database.
    
    Args:
        project_names: List of project names (e.g., ['gCSI', 'CCLE'])
        db_path: Path to the DROMA SQLite database
        
    Returns:
        Status message indicating success or failure
    """
    await ctx.info(f"Creating MultiDromaSet for projects: {', '.join(project_names)}")
    
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "Error: R interface not available"
    
    try:
        if not os.path.exists(db_path):
            return f"Error: Database file not found at {db_path}"
        
        projects_str = '", "'.join(project_names)
        r_code = f"""
        connectDROMADatabase("{db_path}")
        multi_set <- createMultiDromaSetFromDatabase(c("{projects_str}"), "{db_path}")
        paste("Successfully created MultiDromaSet for", length(c("{projects_str}")), "projects")
        """
        
        result = r_interface.execute_r_code(r_code)
        await ctx.info(f"MultiDromaSet created successfully")
        return str(result[0])
        
    except Exception as e:
        error_msg = f"Error creating MultiDromaSet: {str(e)}"
        await ctx.error(error_msg)
        return error_msg

@mcp.tool()
async def analyze_drug_omic_pair(
    omics_type: str,
    omics_name: str,
    drug_name: str,
    project_names: Optional[List[str]] = None,
    data_type: str = "all",
    tumor_type: str = "all",
    overlap_only: bool = False,
    ctx: Context = None
) -> str:
    """
    Analyze association between a drug and an omics feature.
    
    Args:
        omics_type: Type of omics data (e.g., 'mRNA', 'mutation_gene', 'cnv')
        omics_name: Name of the omics feature (e.g., 'ABCB1', 'TP53')
        drug_name: Name of the drug (e.g., 'Paclitaxel')
        project_names: List of project names for MultiDromaSet (optional)
        data_type: Filter by data type ('all', 'CellLine', 'PDX', etc.)
        tumor_type: Filter by tumor type ('all' or specific type)
        overlap_only: Whether to use only overlapping samples
        
    Returns:
        JSON string containing analysis results
    """
    await ctx.info(f"Analyzing {drug_name} vs {omics_name} ({omics_type})")
    
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "Error: R interface not available"
    
    try:
        # Determine if using single or multi project
        if project_names and len(project_names) > 1:
            dataset_var = "multi_set"
        else:
            dataset_var = project_names[0] if project_names else "gCSI"
        
        r_code = f"""
        result <- analyzeDrugOmicPair(
            {dataset_var},
            select_omics_type = "{omics_type}",
            select_omics = "{omics_name}",
            select_drugs = "{drug_name}",
            data_type = "{data_type}",
            tumor_type = "{tumor_type}",
            overlap_only = {str(overlap_only).upper()}
        )
        
        # Extract meta-analysis results if available
        if (!is.null(result$meta)) {{
            meta_summary <- list(
                effect_size = result$meta$TE.random,
                p_value = result$meta$pval.random,
                ci_lower = result$meta$lower.random,
                ci_upper = result$meta$upper.random,
                heterogeneity_i2 = result$meta$I2,
                n_studies = result$meta$k
            )
            jsonlite::toJSON(meta_summary, auto_unbox = TRUE)
        }} else {{
            "No meta-analysis results available"
        }}
        """
        
        result = r_interface.execute_r_code(r_code)
        await ctx.info("Analysis completed successfully")
        return str(result[0])
        
    except Exception as e:
        error_msg = f"Error in drug-omics analysis: {str(e)}"
        await ctx.error(error_msg)
        return error_msg

@mcp.tool()
async def batch_find_significant_features(
    feature1_type: str,
    feature1_name: str,
    feature2_type: str,
    project_names: Optional[List[str]] = None,
    data_type: str = "all",
    tumor_type: str = "all",
    overlap_only: bool = False,
    cores: int = 1,
    test_top_100: bool = True,
    ctx: Context = None
) -> str:
    """
    Perform batch analysis to find features significantly associated with a reference feature.
    
    Args:
        feature1_type: Type of reference feature ('drug', 'mRNA', etc.)
        feature1_name: Name of reference feature
        feature2_type: Type of features to test against
        project_names: List of project names for analysis
        data_type: Filter by data type
        tumor_type: Filter by tumor type
        overlap_only: Whether to use only overlapping samples
        cores: Number of CPU cores for parallel processing
        test_top_100: Whether to test only top 100 features (for speed)
        
    Returns:
        JSON string containing significant features and their statistics
    """
    await ctx.info(f"Starting batch analysis: {feature1_name} ({feature1_type}) vs {feature2_type} features")
    
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "Error: R interface not available"
    
    try:
        # Progress reporting
        await ctx.report_progress(0, "Initializing batch analysis...")
        
        # Determine dataset variable
        if project_names and len(project_names) > 1:
            dataset_var = "multi_set"
        else:
            dataset_var = project_names[0] if project_names else "gCSI"
        
        r_code = f"""
        # Perform batch analysis
        batch_results <- batchFindSignificantFeatures(
            {dataset_var},
            feature1_type = "{feature1_type}",
            feature1_name = "{feature1_name}",
            feature2_type = "{feature2_type}",
            data_type = "{data_type}",
            tumor_type = "{tumor_type}",
            overlap_only = {str(overlap_only).upper()},
            cores = {cores},
            test_top_100 = {str(test_top_100).upper()}
        )
        
        if (!is.null(batch_results) && nrow(batch_results) > 0) {{
            # Sort by p-value and get top results
            sorted_results <- batch_results[order(batch_results$p_value), ]
            top_results <- head(sorted_results, 50)  # Top 50 results
            
            # Convert to JSON
            result_list <- list(
                total_features_tested = nrow(batch_results),
                significant_features = sum(batch_results$p_value < 0.05),
                top_results = top_results
            )
            jsonlite::toJSON(result_list, auto_unbox = FALSE)
        }} else {{
            "No significant results found"
        }}
        """
        
        await ctx.report_progress(50, "Running statistical analysis...")
        result = r_interface.execute_r_code(r_code)
        await ctx.report_progress(100, "Analysis completed")
        await ctx.info("Batch analysis completed successfully")
        
        return str(result[0])
        
    except Exception as e:
        error_msg = f"Error in batch analysis: {str(e)}"
        await ctx.error(error_msg)
        return error_msg

@mcp.tool()
async def create_volcano_plot(
    analysis_results: str,
    effect_size_threshold: float = 0.3,
    p_value_threshold: float = 0.05,
    output_path: Optional[str] = None,
    ctx: Context = None
) -> str:
    """
    Create a volcano plot from batch analysis results.
    
    Args:
        analysis_results: JSON string from batch analysis results
        effect_size_threshold: Effect size threshold for significance
        p_value_threshold: P-value threshold for significance
        output_path: Optional path to save the plot
        
    Returns:
        Path to the generated plot or error message
    """
    await ctx.info("Creating volcano plot...")
    
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "Error: R interface not available"
    
    try:
        # Create output path if not provided
        if not output_path:
            output_path = os.path.join(tempfile.gettempdir(), "volcano_plot.png")
        
        r_code = f"""
        # Assume batch_results is available from previous analysis
        if (exists("batch_results") && !is.null(batch_results)) {{
            # Create volcano plot
            volcano_plot <- plotMetaVolcano(
                batch_results,
                es_t = {effect_size_threshold},
                P_t = {p_value_threshold}
            )
            
            # Save plot
            ggsave("{output_path}", volcano_plot, width = 10, height = 8, dpi = 300)
            "{output_path}"
        }} else {{
            "Error: No batch analysis results available. Run batch analysis first."
        }}
        """
        
        result = r_interface.execute_r_code(r_code)
        plot_path = str(result[0])
        
        if os.path.exists(plot_path):
            await ctx.info(f"Volcano plot saved to: {plot_path}")
            return f"Volcano plot successfully created at: {plot_path}"
        else:
            return "Error creating volcano plot"
        
    except Exception as e:
        error_msg = f"Error creating volcano plot: {str(e)}"
        await ctx.error(error_msg)
        return error_msg

@mcp.tool()
async def get_drug_sensitivity_data(
    drug_name: str,
    project_names: Optional[List[str]] = None,
    data_type: str = "all",
    tumor_type: str = "all",
    include_annotations: bool = True,
    overlap_only: bool = False,
    ctx: Context = None
) -> str:
    """
    Retrieve comprehensive drug sensitivity data.
    
    Args:
        drug_name: Name of the drug
        project_names: List of project names
        data_type: Filter by data type
        tumor_type: Filter by tumor type
        include_annotations: Whether to include sample annotations
        overlap_only: Whether to use only overlapping samples
        
    Returns:
        JSON string containing drug sensitivity data summary
    """
    await ctx.info(f"Retrieving drug sensitivity data for {drug_name}")
    
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "Error: R interface not available"
    
    try:
        # Determine dataset variable
        if project_names and len(project_names) > 1:
            dataset_var = "multi_set"
        else:
            dataset_var = project_names[0] if project_names else "gCSI"
        
        r_code = f"""
        drug_data <- getDrugSensitivityData(
            {dataset_var},
            drug_name = "{drug_name}",
            data_type = "{data_type}",
            tumor_type = "{tumor_type}",
            overlap_only = {str(overlap_only).upper()},
            include_annotations = {str(include_annotations).upper()}
        )
        
        if (!is.null(drug_data) && nrow(drug_data) > 0) {{
            # Create summary
            summary_data <- list(
                total_samples = nrow(drug_data),
                studies = unique(drug_data$study),
                mean_zscore = mean(drug_data$zscore_value, na.rm = TRUE),
                sd_zscore = sd(drug_data$zscore_value, na.rm = TRUE),
                mean_raw = mean(drug_data$raw_value, na.rm = TRUE),
                sd_raw = sd(drug_data$raw_value, na.rm = TRUE)
            )
            
            if ("TumorType" %in% colnames(drug_data)) {{
                summary_data$tumor_types <- table(drug_data$TumorType)
            }}
            
            jsonlite::toJSON(summary_data, auto_unbox = TRUE)
        }} else {{
            "No drug sensitivity data found"
        }}
        """
        
        result = r_interface.execute_r_code(r_code)
        await ctx.info("Drug sensitivity data retrieved successfully")
        return str(result[0])
        
    except Exception as e:
        error_msg = f"Error retrieving drug sensitivity data: {str(e)}"
        await ctx.error(error_msg)
        return error_msg

@mcp.resource("droma://database/info")
async def get_database_info(ctx: Context) -> str:
    """Get information about the connected DROMA database."""
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "R interface not available"
    
    try:
        r_code = """
        # Get database connection info
        if (exists("droma_db_path")) {
            list(
                database_path = droma_db_path,
                connection_status = "connected"
            )
        } else {
            list(
                database_path = "not connected",
                connection_status = "disconnected"
            )
        }
        """
        result = r_interface.execute_r_code(r_code)
        return json.dumps(result)
    except Exception as e:
        return f"Error getting database info: {str(e)}"

@mcp.resource("droma://projects/{project_name}/info")
async def get_project_info(project_name: str, ctx: Context) -> str:
    """Get information about a specific project."""
    r_interface = get_r_interface()
    if not r_interface.is_available():
        return "R interface not available"
    
    try:
        r_code = f"""
        if (exists("{project_name}")) {{
            project_info <- list(
                project_name = "{project_name}",
                class = class({project_name})[1],
                available_drugs = length(availableTreatmentResponses({project_name})),
                available_molecular_profiles = availableMolecularProfiles({project_name})
            )
            jsonlite::toJSON(project_info, auto_unbox = TRUE)
        }} else {{
            "Project not found. Create it first using create_dromaset_from_database."
        }}
        """
        result = r_interface.execute_r_code(r_code)
        return str(result[0])
    except Exception as e:
        return f"Error getting project info: {str(e)}"

@mcp.prompt()
def drug_analysis_prompt(drug_name: str, omics_feature: str) -> str:
    """Generate a prompt for drug-omics analysis interpretation."""
    return f"""
    Please analyze the association between {drug_name} and {omics_feature}.
    
    Consider the following aspects in your analysis:
    1. Statistical significance (p-value)
    2. Effect size and clinical relevance
    3. Biological plausibility of the association
    4. Potential mechanisms of drug resistance/sensitivity
    5. Heterogeneity across different studies or tumor types
    
    If the analysis shows significant association, discuss:
    - Whether this supports known drug mechanisms
    - Potential for biomarker development
    - Clinical implications for patient stratification
    
    If no significant association is found, consider:
    - Sample size limitations
    - Tumor type specificity
    - Alternative biomarkers to explore
    """

@mcp.prompt()
def batch_analysis_interpretation(
    feature_name: str, 
    feature_type: str, 
    significant_count: int, 
    total_count: int
) -> str:
    """Generate a prompt for interpreting batch analysis results."""
    return f"""
    Interpret the batch analysis results for {feature_name} ({feature_type}):
    
    Found {significant_count} significant associations out of {total_count} features tested.
    
    Please analyze:
    1. The enrichment rate ({significant_count}/{total_count} = {significant_count/total_count*100:.1f}%)
    2. Whether this suggests specific biological pathways or mechanisms
    3. The top significant features and their known biological relevance
    4. Potential false discovery rate considerations
    5. Recommendations for follow-up validation studies
    
    Consider the biological context of the feature type and suggest:
    - Which significant associations are most promising for further study
    - Potential pathway enrichment or functional annotation analysis
    - Experimental validation strategies
    """

if __name__ == "__main__":
    # Run the MCP server
    print("Starting DROMA MCP Server...")
    print("Available tools:")
    print("- create_dromaset_from_database: Create DromaSet objects")
    print("- create_multidromaset_from_database: Create MultiDromaSet objects")
    print("- analyze_drug_omic_pair: Analyze drug-omics associations")
    print("- batch_find_significant_features: Batch feature analysis")
    print("- create_volcano_plot: Generate volcano plots")
    print("- get_drug_sensitivity_data: Retrieve drug sensitivity data")
    print("\nResources:")
    print("- droma://database/info: Database connection info")
    print("- droma://projects/{project_name}/info: Project information")
    print("\nPrompts:")
    print("- drug_analysis_prompt: Analysis interpretation guidance")
    print("- batch_analysis_interpretation: Batch results interpretation")
    
    mcp.run() 