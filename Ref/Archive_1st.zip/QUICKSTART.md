# DROMA MCP Server - Quick Start Guide

Get your DROMA drug-omics analysis capabilities connected to AI assistants in minutes!

## 🚀 Quick Installation

### 1. Prerequisites Check

```bash
# Check Python version (need 3.10+)
python --version

# Check R installation
R --version

# Check if rpy2 can be installed
pip install rpy2
```

### 2. Install Dependencies

```bash
# Install Python dependencies
pip install fastmcp rpy2 pandas numpy

# Install R dependencies
R -e "install.packages(c('meta', 'metafor', 'effsize', 'ggplot2', 'dplyr', 'ggpubr', 'DT', 'htmltools', 'patchwork', 'jsonlite'))"
```

### 3. Install DROMA Packages in R

```r
# In R console, install your DROMA packages:
# devtools::install_github("your-repo/DROMA.Set")
# devtools::install_github("your-repo/DROMA.R")

# Or if installed locally:
# install.packages("/path/to/DROMA.Set", repos = NULL, type = "source")
# install.packages("/path/to/DROMA.R", repos = NULL, type = "source")

# Verify installation
library(DROMA.Set)
library(DROMA.R)
```

## 🎯 Quick Test

### 1. Test the Server

```bash
# Start the server (will show available tools)
python droma_mcp_server.py
```

You should see:
```
Starting DROMA MCP Server...
Available tools:
- create_dromaset_from_database: Create DromaSet objects
- create_multidromaset_from_database: Create MultiDromaSet objects
- analyze_drug_omic_pair: Analyze drug-omics associations
...
```

### 2. Test with Example Client

```bash
# Run the test client
python examples/test_client.py
```

Expected output:
```
🚀 Testing DROMA MCP Server...
✅ Connected to DROMA MCP Server
📋 Available Tools:
  - create_dromaset_from_database: Create a DromaSet object...
  - analyze_drug_omic_pair: Analyze association between a drug...
...
```

## 🧬 First Analysis

### 1. Prepare Your Database

Make sure you have a DROMA SQLite database file. Update the path in your tests:

```python
# In examples/test_client.py, update this line:
db_path = "/path/to/your/droma.sqlite"
```

### 2. Run a Complete Analysis

```python
# Update and uncomment this in examples/test_client.py:
await test_with_actual_analysis()
```

Then run:
```bash
python examples/test_client.py
```

## 🤖 Connect to Claude Desktop

### 1. Create MCP Configuration

Create or update your Claude Desktop MCP configuration file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "droma": {
      "command": "python",
      "args": ["/full/path/to/your/droma_mcp_server.py"],
      "env": {
        "R_HOME": "/usr/local/lib/R",
        "PATH": "/usr/local/bin:/usr/bin:/bin"
      }
    }
  }
}
```

### 2. Update Paths

Replace `/full/path/to/your/droma_mcp_server.py` with the actual path to your server file.

### 3. Restart Claude Desktop

Close and reopen Claude Desktop. You should see the DROMA tools available.

## 🎉 Start Analyzing!

Now you can ask Claude to help with drug-omics analysis:

> "Can you create a DromaSet for the gCSI project using my database at /path/to/droma.sqlite?"

> "Analyze the association between Paclitaxel and ABCB1 gene expression across multiple projects"

> "Find all genes significantly associated with Paclitaxel response and create a volcano plot"

## 🔧 Common Issues & Solutions

### Issue: "R interface not available"
**Solution**: 
```bash
pip install rpy2
# On macOS, you might need:
brew install R
```

### Issue: "DROMA packages not found"
**Solution**: Install DROMA.Set and DROMA.R packages in R first

### Issue: "Database file not found"
**Solution**: Update the database path in your configuration/tests

### Issue: "Permission denied"
**Solution**: 
```bash
chmod +x droma_mcp_server.py
```

## 📊 Example Analysis Workflow

1. **Create Dataset**: `create_dromaset_from_database("gCSI", "path/to/db")`
2. **Single Analysis**: `analyze_drug_omic_pair("mRNA", "ABCB1", "Paclitaxel")`
3. **Batch Analysis**: `batch_find_significant_features("drug", "Paclitaxel", "mRNA")`
4. **Visualization**: `create_volcano_plot(results)`
5. **Interpretation**: Use the prompt functions for analysis guidance

## 🆘 Need Help?

- Check the [full README](README.md) for detailed documentation
- Run `python examples/test_client.py` to test connectivity
- Verify R packages are installed: `R -e "library(DROMA.Set); library(DROMA.R)"`
- Check Claude Desktop logs for MCP connection issues

Happy analyzing! 🧬💊🤖 